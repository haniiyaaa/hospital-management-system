﻿$(document).ready(function () {
    $('#resetBtn').click(function () {
        $('textarea').val('');
    });
});